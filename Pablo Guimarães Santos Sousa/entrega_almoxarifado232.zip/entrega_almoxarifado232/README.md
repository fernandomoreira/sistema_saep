# Entrega - Sistema de Controle de Almoxarifado

Este projeto atende ao desafio do SENAI para implantação de um sistema informatizado de controle de almoxarifado.

## Itens da entrega

1. **Diagrama Entidade-Relacionamento:** `docs/DER.md`
2. **Script do banco de dados:** `script_banco.sql`
3. **Back-End Spring Boot:** pasta `src/`

## Como executar o banco

1. Abra o MySQL Workbench.
2. Execute o arquivo `script_banco.sql`.
3. O script cria:
   - Banco `almoxarifado_senai`
   - Tabelas `categoria`, `produto`, `entrada_estoque` e `saida_estoque`
   - Chaves primárias e estrangeiras
   - Registros iniciais, com pelo menos três produtos/categorias/movimentações
   - View `vw_estoque`
   - Consultas de relatório exigidas no trabalho

A view principal é:

```sql
SELECT * FROM vw_estoque;
```

Ela apresenta produto, categoria, unidade de medida, quantidade atual, valor unitário e valor total em estoque.

## Como executar o Back-End

No arquivo `src/main/resources/application.properties`, altere:

```properties
spring.datasource.password=SUA_SENHA_AQUI
```

Coloque a senha do seu MySQL.

Depois execute no terminal dentro da pasta do projeto:

```bash
mvn spring-boot:run
```

A API ficará disponível em:

```text
http://localhost:8080
```

## Endpoints para testar no Postman/Insomnia

### 1. Cadastrar categoria

POST `http://localhost:8080/categorias`

```json
{
  "nome": "Limpeza Geral",
  "descricao": "Produtos utilizados na limpeza diária"
}
```

### 2. Listar categorias

GET `http://localhost:8080/categorias`

### 3. Cadastrar produto com validações

POST `http://localhost:8080/produtos`

```json
{
  "nome": "Sabão em Pó",
  "idCategoria": 1,
  "unidadeMedida": "UN",
  "quantidadeAtual": 10,
  "valorUnitario": 12.50
}
```

Validações implementadas:

- `nome` obrigatório
- `categoria` obrigatória e existente
- `unidadeMedida` obrigatória
- `quantidadeAtual` não pode ser negativa
- `valorUnitario` não pode ser negativo

### 4. Listar todos os produtos cadastrados

GET `http://localhost:8080/produtos`

### 5. Registrar entrada de produto no estoque

POST `http://localhost:8080/estoque/entrada`

```json
{
  "idProduto": 1,
  "quantidade": 5,
  "data": "2026-07-06"
}
```

### 6. Registrar saída de produto do estoque

POST `http://localhost:8080/estoque/saida`

```json
{
  "idProduto": 1,
  "quantidade": 3,
  "data": "2026-07-06"
}
```

Validações da saída:

- Quantidade deve ser maior que zero.
- Produto deve existir.
- Não permite saída maior que o saldo disponível.

### 7. Listar saídas em ordem decrescente por data

GET `http://localhost:8080/estoque/saidas`

### 8. Listar valor total por categoria

GET `http://localhost:8080/relatorios/valor-total-categoria`

Retorna o valor financeiro agrupado por categoria, considerando:

```text
quantidade registrada * valor unitário
```

### 9. Listar movimentações de entrada e saída em um período

GET `http://localhost:8080/relatorios/movimentacoes?dataInicial=2026-07-01&dataFinal=2026-07-31`

Campos retornados:

- Nome do produto
- Unidade de medida
- Total de entradas
- Total de saídas
- Saldo no período
- Valor total financeiro das entradas
- Valor total financeiro das saídas

### 10. Listar produtos com maior volume de saída no período

GET `http://localhost:8080/relatorios/maior-volume-saida?dataInicial=2026-07-01&dataFinal=2026-07-31`

Ordem dos campos:

- Nome do produto
- Quantidade total de saída
- Valor total financeiro das saídas

A ordenação é decrescente pela quantidade total de saída.

### 11. Identificar produtos que atingiram limite mínimo e máximo

GET `http://localhost:8080/relatorios/limites-estoque`

Regra usada:

- Limite mínimo: quantidade atual menor ou igual a `0`
- Limite máximo: quantidade atual maior ou igual a `100`

Campos retornados:

- Nome do produto
- Quantidade atual
- Limite atingido
- Percentual do nível atingido

## Regras de negócio implementadas

- Cadastro de produto com validação de valor unitário, quantidade e categoria.
- Entrada aumenta automaticamente o saldo do produto.
- Saída diminui automaticamente o saldo do produto.
- Não é permitido registrar saída maior que o estoque disponível.
- Relatórios disponíveis via endpoints REST.
- Retornos podem ser visualizados no console, navegador, Postman ou Insomnia.
