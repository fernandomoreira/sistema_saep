CREATE DATABASE IF NOT EXISTS almoxarifado_senai;
USE almoxarifado_senai;

DROP VIEW IF EXISTS vw_estoque;
DROP TABLE IF EXISTS auditoria;
DROP TABLE IF EXISTS saida_estoque;
DROP TABLE IF EXISTS entrada_estoque;
DROP TABLE IF EXISTS produto;
DROP TABLE IF EXISTS categoria;

CREATE TABLE categoria (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255)
);

CREATE TABLE produto (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    id_categoria INT NOT NULL,
    unidade_medida VARCHAR(20) NOT NULL,
    quantidade_atual INT NOT NULL DEFAULT 0,
    valor_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_produto_categoria
        FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria),
    CONSTRAINT chk_quantidade_atual CHECK (quantidade_atual >= 0),
    CONSTRAINT chk_valor_unitario CHECK (valor_unitario >= 0)
);

CREATE TABLE entrada_estoque (
    id_entrada INT AUTO_INCREMENT PRIMARY KEY,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    data_entrada DATE NOT NULL,
    CONSTRAINT fk_entrada_produto
        FOREIGN KEY (id_produto) REFERENCES produto(id_produto),
    CONSTRAINT chk_entrada_quantidade CHECK (quantidade > 0)
);

CREATE TABLE saida_estoque (
    id_saida INT AUTO_INCREMENT PRIMARY KEY,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    data_saida DATE NOT NULL,
    CONSTRAINT fk_saida_produto
        FOREIGN KEY (id_produto) REFERENCES produto(id_produto),
    CONSTRAINT chk_saida_quantidade CHECK (quantidade > 0)
);

CREATE TABLE auditoria (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100) NOT NULL,
    acao VARCHAR(30) NOT NULL,
    entidade VARCHAR(50) NOT NULL,
    id_registro INT,
    descricao VARCHAR(500) NOT NULL,
    data_hora DATETIME NOT NULL
);

INSERT INTO categoria (nome, descricao) VALUES
('Limpeza Geral', 'Produtos utilizados na limpeza diaria'),
('Higiene', 'Materiais de higiene pessoal e coletiva'),
('Descartaveis', 'Itens descartaveis utilizados pela empresa');

INSERT INTO produto (nome, id_categoria, unidade_medida, quantidade_atual, valor_unitario) VALUES
('Detergente Neutro 500ml', 1, 'UN', 40, 2.50),
('Papel Higienico Fardo', 2, 'FD', 25, 18.90),
('Copo Descartavel 200ml Pacote', 3, 'PC', 80, 5.75),
('Alcool 70%', 1, 'UN', 0, 8.99),
('Luva de Limpeza Par', 2, 'PAR', 100, 4.50);

INSERT INTO entrada_estoque (id_produto, quantidade, data_entrada) VALUES
(1, 50, '2026-07-01'),
(2, 30, '2026-07-01'),
(3, 100, '2026-07-01'),
(4, 10, '2026-07-02'),
(5, 100, '2026-07-02');

INSERT INTO saida_estoque (id_produto, quantidade, data_saida) VALUES
(1, 10, '2026-07-02'),
(2, 5, '2026-07-02'),
(3, 20, '2026-07-03'),
(4, 10, '2026-07-04');

-- Os saldos atuais dos produtos ja foram cadastrados considerando entradas e saidas.

CREATE VIEW vw_estoque AS
SELECT
    p.id_produto,
    p.nome AS produto,
    c.nome AS categoria,
    p.unidade_medida,
    p.quantidade_atual,
    p.valor_unitario,
    (p.quantidade_atual * p.valor_unitario) AS valor_total
FROM produto p
INNER JOIN categoria c ON p.id_categoria = c.id_categoria;

-- Consultas uteis para testar a entrega
SELECT * FROM vw_estoque;

-- Valor total por categoria
SELECT c.nome AS categoria,
       SUM(p.quantidade_atual * p.valor_unitario) AS valor_total
FROM produto p
INNER JOIN categoria c ON c.id_categoria = p.id_categoria
GROUP BY c.id_categoria, c.nome
ORDER BY valor_total DESC;

-- Saidas em ordem decrescente por data
SELECT s.id_saida, p.nome AS produto, s.quantidade, s.data_saida
FROM saida_estoque s
INNER JOIN produto p ON p.id_produto = s.id_produto
ORDER BY s.data_saida DESC;

-- Movimentacoes por periodo
SET @data_inicial = '2026-07-01';
SET @data_final = '2026-07-31';
SELECT p.nome AS nome_produto,
       p.unidade_medida,
       COALESCE(ent.total_entradas, 0) AS total_entradas,
       COALESCE(sai.total_saidas, 0) AS total_saidas,
       COALESCE(ent.total_entradas, 0) - COALESCE(sai.total_saidas, 0) AS saldo_periodo,
       COALESCE(ent.total_entradas, 0) * p.valor_unitario AS valor_total_financeiro_entradas,
       COALESCE(sai.total_saidas, 0) * p.valor_unitario AS valor_total_financeiro_saidas
FROM produto p
LEFT JOIN (
    SELECT id_produto, SUM(quantidade) AS total_entradas
    FROM entrada_estoque
    WHERE data_entrada BETWEEN @data_inicial AND @data_final
    GROUP BY id_produto
) ent ON ent.id_produto = p.id_produto
LEFT JOIN (
    SELECT id_produto, SUM(quantidade) AS total_saidas
    FROM saida_estoque
    WHERE data_saida BETWEEN @data_inicial AND @data_final
    GROUP BY id_produto
) sai ON sai.id_produto = p.id_produto
ORDER BY p.nome ASC;

-- Produtos com maior volume de saida no periodo
SELECT p.nome AS nome_produto,
       SUM(s.quantidade) AS quantidade_total_saida,
       SUM(s.quantidade * p.valor_unitario) AS valor_total_financeiro_saidas
FROM saida_estoque s
INNER JOIN produto p ON p.id_produto = s.id_produto
WHERE s.data_saida BETWEEN @data_inicial AND @data_final
GROUP BY p.id_produto, p.nome
ORDER BY quantidade_total_saida DESC;

-- Produtos que atingiram limite minimo 0 ou maximo 100
SELECT p.nome AS nome_produto,
       p.quantidade_atual,
       CASE
           WHEN p.quantidade_atual <= 0 THEN 'LIMITE_MINIMO'
           WHEN p.quantidade_atual >= 100 THEN 'LIMITE_MAXIMO'
       END AS limite_atingido,
       CASE
           WHEN p.quantidade_atual <= 0 THEN 0
           ELSE ROUND((p.quantidade_atual / 100) * 100, 2)
       END AS percentual_nivel_atingido
FROM produto p
WHERE p.quantidade_atual <= 0 OR p.quantidade_atual >= 100
ORDER BY p.quantidade_atual DESC;

-- Relatorio de auditoria: mostra quem realizou cada alteracao
SELECT usuario,
       acao,
       entidade,
       id_registro,
       descricao,
       data_hora
FROM auditoria
ORDER BY data_hora DESC;
