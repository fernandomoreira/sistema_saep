# Guia de Testes da API Almoxarifado com Insomnia

## Como importar a coleção

1. Abra o Insomnia (https://insomnia.rest/)
2. Clique em **File** → **Import**
3. Selecione **From File**
4. Escolha o arquivo `Insomnia_Collection.json`
5. A coleção será importada com todas as requisições já configuradas

## Endpoints disponíveis

### CATEGORIAS

#### 1. GET - Listar Categorias
- **URL:** `http://localhost:8080/categorias`
- **Método:** GET
- **Resposta esperada:** Lista de categorias em JSON

```json
[
  {
    "id": 1,
    "nome": "Eletrônicos",
    "descricao": null
  }
]
```

#### 2. POST - Criar Categoria
- **URL:** `http://localhost:8080/categorias`
- **Método:** POST
- **Headers:** `Content-Type: application/json`
- **Body:**
```json
{
  "nome": "Eletrônicos"
}
```

---

### PRODUTOS

#### 3. GET - Listar Produtos
- **URL:** `http://localhost:8080/produtos`
- **Método:** GET
- **Resposta esperada:** Lista de produtos com categoria

```json
[
  {
    "id": 1,
    "nome": "Notebook",
    "categoria": {
      "id": 1,
      "nome": "Eletrônicos"
    },
    "unidadeMedida": "UN",
    "quantidadeAtual": 10,
    "valorUnitario": 3500.00
  }
]
```

#### 4. POST - Criar Produto
- **URL:** `http://localhost:8080/produtos`
- **Método:** POST
- **Headers:** `Content-Type: application/json`
- **Body:**
```json
{
  "nome": "Notebook",
  "idCategoria": 1,
  "unidadeMedida": "UN",
  "valorUnitario": 3500.00,
  "quantidadeAtual": 10
}
```

---

### ESTOQUE

#### 5. POST - Registrar Entrada
- **URL:** `http://localhost:8080/estoque/entrada`
- **Método:** POST
- **Headers:** `Content-Type: application/json`
- **Body:**
```json
{
  "idProduto": 1,
  "quantidade": 5
}
```

#### 6. POST - Registrar Saída
- **URL:** `http://localhost:8080/estoque/saida`
- **Método:** POST
- **Headers:** `Content-Type: application/json`
- **Body:**
```json
{
  "idProduto": 1,
  "quantidade": 2
}
```

#### 7. GET - Listar Saídas
- **URL:** `http://localhost:8080/estoque/saidas`
- **Método:** GET
- **Resposta esperada:** Lista de saídas ordenadas por data decrescente

```json
[
  {
    "id": 1,
    "produto": {
      "id": 1,
      "nome": "Notebook"
    },
    "quantidade": 2,
    "dataSaida": "2026-07-06"
  }
]
```

---

### RELATÓRIOS

#### 8. GET - Valor Total por Categoria
- **URL:** `http://localhost:8080/relatorios/valor-total-categoria`
- **Método:** GET
- **Resposta esperada:**
```json
[
  {
    "categoria": "Eletrônicos",
    "valor_total": 35000.00
  }
]
```

#### 9. GET - Maior Volume de Saída
- **URL:** `http://localhost:8080/relatorios/maior-volume-saida?dataInicial=2024-01-01&dataFinal=2026-12-31`
- **Método:** GET
- **Parâmetros:**
  - `dataInicial` (YYYY-MM-DD)
  - `dataFinal` (YYYY-MM-DD)
- **Resposta esperada:**
```json
[
  {
    "nome_produto": "Notebook",
    "quantidade_total_saida": 10,
    "valor_total_financeiro_saidas": 35000.00
  }
]
```

#### 10. GET - Produtos em Limite de Estoque
- **URL:** `http://localhost:8080/relatorios/limites-estoque`
- **Método:** GET
- **Resposta esperada:**
```json
[
  {
    "nome_produto": "Notebook",
    "quantidade_atual": 0,
    "limite_atingido": "LIMITE_MINIMO",
    "percentual_nivel_atingido": 0
  }
]
```

#### 11. GET - Movimentações por Período
- **URL:** `http://localhost:8080/relatorios/movimentacoes?dataInicial=2024-01-01&dataFinal=2026-12-31`
- **Método:** GET
- **Parâmetros:**
  - `dataInicial` (YYYY-MM-DD)
  - `dataFinal` (YYYY-MM-DD)
- **Resposta esperada:**
```json
[
  {
    "nome_produto": "Notebook",
    "unidade_medida": "UN",
    "total_entradas": 15,
    "total_saidas": 5,
    "saldo_periodo": 10,
    "valor_total_financeiro_entradas": 52500.00,
    "valor_total_financeiro_saidas": 17500.00
  }
]
```

---

## Fluxo de teste recomendado

1. **Criar uma categoria:**
   - POST `/categorias` com nome "Eletrônicos"

2. **Criar um produto:**
   - POST `/produtos` com a categoria criada (id = 1)

3. **Registrar entrada no estoque:**
   - POST `/estoque/entrada` com produto id = 1, quantidade = 10

4. **Listar produtos:**
   - GET `/produtos` (deve mostrar quantidade = 10)

5. **Registrar saída:**
   - POST `/estoque/saida` com produto id = 1, quantidade = 3

6. **Listar saídas:**
   - GET `/estoque/saidas` (deve aparecer uma saída)

7. **Testar relatórios:**
   - GET `/relatorios/valor-total-categoria`
   - GET `/relatorios/maior-volume-saida?dataInicial=2024-01-01&dataFinal=2026-12-31`
   - GET `/relatorios/movimentacoes?dataInicial=2024-01-01&dataFinal=2026-12-31`

---

## Observações

- **Base URL:** `http://localhost:8080`
- Certifique-se que o backend está rodando antes de fazer requisições
- As datas nos relatórios devem estar no formato YYYY-MM-DD
- Todos os IDs no POST devem ser números inteiros
- As quantidades devem ser números positivos

---

## Variáveis de ambiente no Insomnia (opcional)

Você pode configurar uma variável `base_url` na coleção para facilitar:
1. No Insomnia, clique em **Environment**
2. Escolha **Local Development**
3. Configure:
   - `base_url`: `http://localhost:8080`

---

## Estrutura da coleção

```
Almoxarifado API
├── Categorias
│   ├── GET - Listar Categorias
│   └── POST - Criar Categoria
├── Produtos
│   ├── GET - Listar Produtos
│   └── POST - Criar Produto
├── Estoque
│   ├── POST - Registrar Entrada
│   ├── POST - Registrar Saída
│   └── GET - Listar Saídas
└── Relatórios
    ├── GET - Valor Total por Categoria
    ├── GET - Maior Volume de Saída
    ├── GET - Produtos em Limite de Estoque
    └── GET - Movimentações por Período
```
