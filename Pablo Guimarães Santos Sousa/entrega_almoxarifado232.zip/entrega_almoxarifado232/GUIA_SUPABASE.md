# Guia: Migrar de API Java para Supabase

## Por que Supabase ao invés da API Java?

- ✅ Sem necessidade de instalar Maven
- ✅ Sem necessidade de servidor Java rodando
- ✅ Front-end comunica direto com banco de dados
- ✅ Hospedagem gratuita
- ✅ Fácil de configurar

---

## Passo 1: Criar conta no Supabase

1. Acesse https://supabase.com
2. Clique em **Sign Up**
3. Cadastre-se com GitHub ou email
4. Crie um novo projeto

---

## Passo 2: Criar as tabelas

No painel do Supabase, vá para **SQL Editor** e copie/cole este código:

```sql
-- Criar tabela categoria
CREATE TABLE categoria (
    id_categoria BIGSERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255)
);

-- Criar tabela produto
CREATE TABLE produto (
    id_produto BIGSERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    id_categoria BIGINT NOT NULL REFERENCES categoria(id_categoria),
    unidade_medida VARCHAR(20) NOT NULL,
    quantidade_atual INT NOT NULL DEFAULT 0 CHECK (quantidade_atual >= 0),
    valor_unitario DECIMAL(10, 2) NOT NULL CHECK (valor_unitario >= 0)
);

-- Criar tabela entrada_estoque
CREATE TABLE entrada_estoque (
    id_entrada BIGSERIAL PRIMARY KEY,
    id_produto BIGINT NOT NULL REFERENCES produto(id_produto),
    quantidade INT NOT NULL CHECK (quantidade > 0),
    data_entrada DATE NOT NULL
);

-- Criar tabela saida_estoque
CREATE TABLE saida_estoque (
    id_saida BIGSERIAL PRIMARY KEY,
    id_produto BIGINT NOT NULL REFERENCES produto(id_produto),
    quantidade INT NOT NULL CHECK (quantidade > 0),
    data_saida DATE NOT NULL
);

-- Inserir dados de exemplo
INSERT INTO categoria (nome, descricao) VALUES
('Limpeza Geral', 'Produtos utilizados na limpeza diária'),
('Higiene', 'Materiais de higiene pessoal e coletiva'),
('Descartáveis', 'Itens descartáveis utilizados pela empresa');

INSERT INTO produto (nome, id_categoria, unidade_medida, quantidade_atual, valor_unitario) VALUES
('Detergente Neutro 500ml', 1, 'UN', 40, 2.50),
('Papel Higiênico Fardo', 2, 'FD', 25, 18.90),
('Copo Descartável 200ml Pacote', 3, 'PC', 80, 5.75),
('Álcool 70%', 1, 'UN', 0, 8.99);

INSERT INTO entrada_estoque (id_produto, quantidade, data_entrada) VALUES
(1, 50, '2026-07-01'),
(2, 30, '2026-07-01'),
(3, 100, '2026-07-01'),
(4, 10, '2026-07-02');

INSERT INTO saida_estoque (id_produto, quantidade, data_saida) VALUES
(1, 10, '2026-07-02'),
(2, 5, '2026-07-02'),
(3, 20, '2026-07-03'),
(4, 10, '2026-07-04');

-- Criar VIEW de estoque
CREATE VIEW vw_estoque AS
SELECT
    p.id_produto,
    p.nome AS produto,
    c.nome AS categoria,
    p.unidade_medida,
    p.quantidade_atual,
    p.valor_unitario,
    (p.quantidade_atual * p.valor_unitario) AS valor_total
FROM produto p
INNER JOIN categoria c ON p.id_categoria = c.id_categoria;

-- Habilitar Row Level Security
ALTER TABLE categoria ENABLE ROW LEVEL SECURITY;
ALTER TABLE produto ENABLE ROW LEVEL SECURITY;
ALTER TABLE entrada_estoque ENABLE ROW LEVEL SECURITY;
ALTER TABLE saida_estoque ENABLE ROW LEVEL SECURITY;

-- Criar políticas de acesso público (sem autenticação)
CREATE POLICY "Allow public read categoria" ON categoria FOR SELECT USING (true);
CREATE POLICY "Allow public insert categoria" ON categoria FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public read produto" ON produto FOR SELECT USING (true);
CREATE POLICY "Allow public insert produto" ON produto FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public read entrada_estoque" ON entrada_estoque FOR SELECT USING (true);
CREATE POLICY "Allow public insert entrada_estoque" ON entrada_estoque FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public read saida_estoque" ON saida_estoque FOR SELECT USING (true);
CREATE POLICY "Allow public insert saida_estoque" ON saida_estoque FOR INSERT WITH CHECK (true);
```

Depois de copiar, clique em **Run** ou **Ctrl+Enter**.

---

## Passo 3: Pegar as credenciais

1. No painel, vá para **Settings** → **API**
2. Copie:
   - **Project URL** (exemplo: `https://your-project.supabase.co`)
   - **anon public** (a chave pública)

---

## Passo 4: Atualizar `config.js`

Abra `src/main/resources/static/config.js` e substitua as credenciais:

```javascript
const SUPABASE_URL = 'https://seu-projeto.supabase.co'; // Cole sua URL
const SUPABASE_KEY = 'sua_chave_publica_aqui'; // Cole sua chave

const { createClient } = supabase;
const supabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY);
```

---

## Passo 5: Atualizar `app.js`

Para usar Supabase ao invés de chamadas HTTP fetch, faça as seguintes mudanças principais:

### Exemplo 1: Listar categorias (antigo vs novo)

**ANTES (fetch HTTP):**
```javascript
function carregarCategorias() {
    fetch(`${API_URL}/categorias`)
        .then(response => response.json())
        .then(data => { /* ... */ })
}
```

**DEPOIS (Supabase):**
```javascript
async function carregarCategorias() {
    try {
        const { data, error } = await db.from('categoria').select('*');
        if (error) throw error;
        // ... usar data
    } catch (error) {
        console.error('Erro:', error);
    }
}
```

### Exemplo 2: Inserir categoria

**ANTES:**
```javascript
fetch(`${API_URL}/categorias`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome: nome })
})
```

**DEPOIS:**
```javascript
const { error } = await db.from('categoria').insert([{ nome: nome }]);
if (error) throw error;
```

---

## Passo 6: Agora teste!

1. Abra seu projeto no navegador: `file:///C:/Users/aluno.den/Downloads/entrega_almoxarifado/entrega_almoxarifado/src/main/resources/static/index.html`
2. Ou inicie um servidor local simples:
   ```powershell
   cd src/main/resources/static
   python -m http.server 8000
   ```
   Depois abra `http://localhost:8000`

3. Teste as funcionalidades:
   - Adicionar categoria
   - Adicionar produto
   - Registrar entrada
   - Registrar saída
   - Ver relatórios

---

## Estrutura das tabelas Supabase

```
categoria
├── id_categoria (BIGSERIAL, PK)
├── nome (VARCHAR)
└── descricao (VARCHAR)

produto
├── id_produto (BIGSERIAL, PK)
├── nome (VARCHAR)
├── id_categoria (FK → categoria.id_categoria)
├── unidade_medida (VARCHAR)
├── quantidade_atual (INT, CHECK >= 0)
└── valor_unitario (DECIMAL, CHECK >= 0)

entrada_estoque
├── id_entrada (BIGSERIAL, PK)
├── id_produto (FK → produto.id_produto)
├── quantidade (INT, CHECK > 0)
└── data_entrada (DATE)

saida_estoque
├── id_saida (BIGSERIAL, PK)
├── id_produto (FK → produto.id_produto)
├── quantidade (INT, CHECK > 0)
└── data_saida (DATE)

vw_estoque (VIEW)
├── id_produto
├── produto
├── categoria
├── unidade_medida
├── quantidade_atual
├── valor_unitario
└── valor_total (calculado)
```

---

## Vantagens

✅ Sem instalação de Maven
✅ Sem servidor Java
✅ Front-end roda localmente
✅ Dados hospedados na nuvem (Supabase)
✅ Fácil de testar
✅ Gratuito até certos limites

---

## Próximos passos

Se quiser testar apenas o front-end sem backend:
1. Configure Supabase conforme este guia
2. Abra o HTML no navegador
3. Não é necessário rodar Maven ou qualquer servidor Java
