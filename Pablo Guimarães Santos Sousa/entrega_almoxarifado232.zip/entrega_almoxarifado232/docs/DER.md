# Diagrama Entidade-Relacionamento - Almoxarifado

```mermaid
erDiagram
    CATEGORIA ||--o{ PRODUTO : possui
    PRODUTO ||--o{ ENTRADA_ESTOQUE : recebe
    PRODUTO ||--o{ SAIDA_ESTOQUE : movimenta

    CATEGORIA {
        int id_categoria PK
        varchar nome
        varchar descricao
    }

    PRODUTO {
        int id_produto PK
        varchar nome
        int id_categoria FK
        varchar unidade_medida
        int quantidade_atual
        decimal valor_unitario
    }

    ENTRADA_ESTOQUE {
        int id_entrada PK
        int id_produto FK
        int quantidade
        date data_entrada
    }

    SAIDA_ESTOQUE {
        int id_saida PK
        int id_produto FK
        int quantidade
        date data_saida
    }
```

## Relacionamentos e cardinalidades

- Uma categoria pode possuir varios produtos.
- Cada produto pertence obrigatoriamente a uma categoria.
- Um produto pode ter varias entradas de estoque.
- Um produto pode ter varias saidas de estoque.
- Cada entrada ou saida pertence obrigatoriamente a um produto.

## Regras representadas no modelo

- Produto possui quantidade atual, unidade de medida e valor unitario.
- Entrada aumenta o saldo do produto.
- Saida diminui o saldo do produto.
- A view `vw_estoque` calcula o valor total por item: `quantidade_atual * valor_unitario`.
- O estoque usa limite minimo igual a 0 e limite maximo igual a 100 unidades.
