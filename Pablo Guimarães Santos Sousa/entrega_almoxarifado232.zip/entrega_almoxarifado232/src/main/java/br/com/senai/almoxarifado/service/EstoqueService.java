package br.com.senai.almoxarifado.service;

import br.com.senai.almoxarifado.dto.MovimentacaoDTO;
import br.com.senai.almoxarifado.entity.EntradaEstoque;
import br.com.senai.almoxarifado.entity.Produto;
import br.com.senai.almoxarifado.entity.SaidaEstoque;
import br.com.senai.almoxarifado.exception.RegraNegocioException;
import br.com.senai.almoxarifado.repository.EntradaEstoqueRepository;
import br.com.senai.almoxarifado.repository.ProdutoRepository;
import br.com.senai.almoxarifado.repository.SaidaEstoqueRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
public class EstoqueService {
    private static final int LIMITE_MAXIMO_ESTOQUE = 100;

    private final ProdutoRepository produtoRepository;
    private final EntradaEstoqueRepository entradaRepository;
    private final SaidaEstoqueRepository saidaRepository;
    private final AuditoriaService auditoriaService;

    public EstoqueService(ProdutoRepository produtoRepository,
                          EntradaEstoqueRepository entradaRepository,
                          SaidaEstoqueRepository saidaRepository,
                          AuditoriaService auditoriaService) {
        this.produtoRepository = produtoRepository;
        this.entradaRepository = entradaRepository;
        this.saidaRepository = saidaRepository;
        this.auditoriaService = auditoriaService;
    }

    @Transactional
    public EntradaEstoque registrarEntrada(MovimentacaoDTO dto, String usuario) {
        validarQuantidade(dto.quantidade);
        Produto produto = buscarProduto(dto.idProduto);

        int novoSaldo = produto.getQuantidadeAtual() + dto.quantidade;
        if (novoSaldo > LIMITE_MAXIMO_ESTOQUE) {
            throw new RegraNegocioException("A entrada ultrapassa o limite maximo de 100 unidades em estoque.");
        }

        produto.setQuantidadeAtual(novoSaldo);
        produtoRepository.save(produto);

        EntradaEstoque entrada = new EntradaEstoque();
        entrada.setProduto(produto);
        entrada.setQuantidade(dto.quantidade);
        entrada.setDataEntrada(dto.data == null ? LocalDate.now() : dto.data);

        EntradaEstoque salva = entradaRepository.save(entrada);
        auditoriaService.registrar(usuario, "REGISTROU_ENTRADA", "Estoque", salva.getId(),
                "Registrou entrada de " + dto.quantidade + " unidade(s) para o produto: " + produto.getNome());
        return salva;
    }

    @Transactional
    public SaidaEstoque registrarSaida(MovimentacaoDTO dto, String usuario) {
        validarQuantidade(dto.quantidade);
        Produto produto = buscarProduto(dto.idProduto);

        if (produto.getQuantidadeAtual() < dto.quantidade) {
            throw new RegraNegocioException("Estoque insuficiente para realizar a saida.");
        }

        produto.setQuantidadeAtual(produto.getQuantidadeAtual() - dto.quantidade);
        produtoRepository.save(produto);

        SaidaEstoque saida = new SaidaEstoque();
        saida.setProduto(produto);
        saida.setQuantidade(dto.quantidade);
        saida.setDataSaida(dto.data == null ? LocalDate.now() : dto.data);

        SaidaEstoque salva = saidaRepository.save(saida);
        auditoriaService.registrar(usuario, "REGISTROU_SAIDA", "Estoque", salva.getId(),
                "Registrou saida de " + dto.quantidade + " unidade(s) para o produto: " + produto.getNome());
        return salva;
    }

    private Produto buscarProduto(Integer idProduto) {
        if (idProduto == null) {
            throw new RegraNegocioException("O produto e obrigatorio.");
        }
        return produtoRepository.findById(idProduto)
                .orElseThrow(() -> new RegraNegocioException("Produto nao encontrado."));
    }

    private void validarQuantidade(Integer quantidade) {
        if (quantidade == null || quantidade <= 0) {
            throw new RegraNegocioException("A quantidade deve ser maior que zero.");
        }
    }
}
