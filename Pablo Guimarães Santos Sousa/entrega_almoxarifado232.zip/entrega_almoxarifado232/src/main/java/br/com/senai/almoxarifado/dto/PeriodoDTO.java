package br.com.senai.almoxarifado.dto;

import java.time.LocalDate;

public class PeriodoDTO {
    public LocalDate dataInicial;
    public LocalDate dataFinal;
}
