package br.com.senai.almoxarifado.dto;

import java.math.BigDecimal;

public class ProdutoDTO {
    public String nome;
    public Integer idCategoria;
    public String unidadeMedida;
    public Integer quantidadeAtual;
    public BigDecimal valorUnitario;
}
