package br.com.senai.almoxarifado.dto;

import java.time.LocalDate;

public class MovimentacaoDTO {
    public Integer idProduto;
    public Integer quantidade;
    public LocalDate data;
}
