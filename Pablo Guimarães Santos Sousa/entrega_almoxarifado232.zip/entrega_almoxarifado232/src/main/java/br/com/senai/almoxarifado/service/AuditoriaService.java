package br.com.senai.almoxarifado.service;

import br.com.senai.almoxarifado.entity.Auditoria;
import br.com.senai.almoxarifado.repository.AuditoriaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditoriaService {
    private final AuditoriaRepository repository;

    public AuditoriaService(AuditoriaRepository repository) {
        this.repository = repository;
    }

    public void registrar(String usuario, String acao, String entidade, Integer idRegistro, String descricao) {
        Auditoria auditoria = new Auditoria();
        auditoria.setUsuario(normalizarUsuario(usuario));
        auditoria.setAcao(acao);
        auditoria.setEntidade(entidade);
        auditoria.setIdRegistro(idRegistro);
        auditoria.setDescricao(descricao);
        auditoria.setDataHora(LocalDateTime.now());
        repository.save(auditoria);
    }

    public List<Auditoria> listar() {
        return repository.findAllByOrderByDataHoraDesc();
    }

    private String normalizarUsuario(String usuario) {
        if (usuario == null || usuario.isBlank()) {
            return "Usuario nao informado";
        }
        return usuario.trim();
    }
}
