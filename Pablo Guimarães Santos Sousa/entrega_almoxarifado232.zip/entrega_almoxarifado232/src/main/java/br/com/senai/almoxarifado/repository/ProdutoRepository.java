package br.com.senai.almoxarifado.repository;

import br.com.senai.almoxarifado.entity.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
    boolean existsByCategoriaId(Integer idCategoria);
}
