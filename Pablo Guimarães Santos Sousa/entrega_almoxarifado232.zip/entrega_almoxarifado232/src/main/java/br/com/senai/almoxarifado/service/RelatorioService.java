package br.com.senai.almoxarifado.service;

import br.com.senai.almoxarifado.exception.RegraNegocioException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class RelatorioService {
    private final JdbcTemplate jdbcTemplate;

    public RelatorioService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> valorTotalPorCategoria() {
        String sql = """
                SELECT c.nome AS categoria,
                       SUM(p.quantidade_atual * p.valor_unitario) AS valor_total
                FROM produto p
                INNER JOIN categoria c ON c.id_categoria = p.id_categoria
                GROUP BY c.id_categoria, c.nome
                ORDER BY valor_total DESC
                """;
        return jdbcTemplate.queryForList(sql);
    }

    public List<Map<String, Object>> movimentacoesPorPeriodo(LocalDate dataInicial, LocalDate dataFinal) {
        validarPeriodo(dataInicial, dataFinal);
        String sql = """
                SELECT p.nome AS nome_produto,
                       p.unidade_medida,
                       COALESCE(ent.total_entradas, 0) AS total_entradas,
                       COALESCE(sai.total_saidas, 0) AS total_saidas,
                       COALESCE(ent.total_entradas, 0) - COALESCE(sai.total_saidas, 0) AS saldo_periodo,
                       COALESCE(ent.total_entradas, 0) * p.valor_unitario AS valor_total_financeiro_entradas,
                       COALESCE(sai.total_saidas, 0) * p.valor_unitario AS valor_total_financeiro_saidas
                FROM produto p
                LEFT JOIN (
                    SELECT id_produto, SUM(quantidade) AS total_entradas
                    FROM entrada_estoque
                    WHERE data_entrada BETWEEN ? AND ?
                    GROUP BY id_produto
                ) ent ON ent.id_produto = p.id_produto
                LEFT JOIN (
                    SELECT id_produto, SUM(quantidade) AS total_saidas
                    FROM saida_estoque
                    WHERE data_saida BETWEEN ? AND ?
                    GROUP BY id_produto
                ) sai ON sai.id_produto = p.id_produto
                ORDER BY p.nome ASC
                """;
        return jdbcTemplate.queryForList(sql, dataInicial, dataFinal, dataInicial, dataFinal);
    }

    public List<Map<String, Object>> produtosMaiorVolumeSaida(LocalDate dataInicial, LocalDate dataFinal) {
        validarPeriodo(dataInicial, dataFinal);
        String sql = """
                SELECT p.nome AS nome_produto,
                       SUM(s.quantidade) AS quantidade_total_saida,
                       SUM(s.quantidade * p.valor_unitario) AS valor_total_financeiro_saidas
                FROM saida_estoque s
                INNER JOIN produto p ON p.id_produto = s.id_produto
                WHERE s.data_saida BETWEEN ? AND ?
                GROUP BY p.id_produto, p.nome
                ORDER BY quantidade_total_saida DESC
                """;
        return jdbcTemplate.queryForList(sql, dataInicial, dataFinal);
    }

    public List<Map<String, Object>> produtosLimiteEstoque() {
        String sql = """
                SELECT p.nome AS nome_produto,
                       p.quantidade_atual,
                       CASE
                           WHEN p.quantidade_atual <= 0 THEN 'LIMITE_MINIMO'
                           WHEN p.quantidade_atual >= 100 THEN 'LIMITE_MAXIMO'
                       END AS limite_atingido,
                       CASE
                           WHEN p.quantidade_atual <= 0 THEN 0
                           ELSE ROUND((p.quantidade_atual / 100) * 100, 2)
                       END AS percentual_nivel_atingido
                FROM produto p
                WHERE p.quantidade_atual <= 0 OR p.quantidade_atual >= 100
                ORDER BY p.quantidade_atual DESC
                """;
        return jdbcTemplate.queryForList(sql);
    }

    private void validarPeriodo(LocalDate dataInicial, LocalDate dataFinal) {
        if (dataInicial == null || dataFinal == null) {
            throw new RegraNegocioException("Data inicial e data final sao obrigatorias.");
        }
        if (dataInicial.isAfter(dataFinal)) {
            throw new RegraNegocioException("A data inicial nao pode ser maior que a data final.");
        }
    }
}
