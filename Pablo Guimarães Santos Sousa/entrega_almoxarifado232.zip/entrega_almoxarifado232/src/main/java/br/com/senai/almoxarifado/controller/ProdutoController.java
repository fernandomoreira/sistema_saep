package br.com.senai.almoxarifado.controller;

import br.com.senai.almoxarifado.dto.ProdutoDTO;
import br.com.senai.almoxarifado.entity.Produto;
import br.com.senai.almoxarifado.service.ProdutoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {
    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping
    public Produto cadastrar(@RequestBody ProdutoDTO dto,
                             @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.cadastrar(dto, usuario);
    }

    @GetMapping
    public List<Produto> listar() {
        return service.listar();
    }

    @PutMapping("/{id}")
    public Produto atualizar(@PathVariable Integer id,
                             @RequestBody ProdutoDTO dto,
                             @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.atualizar(id, dto, usuario);
    }

    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Integer id,
                        @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        service.excluir(id, usuario);
    }
}
