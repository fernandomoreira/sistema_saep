package br.com.senai.almoxarifado.controller;

import br.com.senai.almoxarifado.service.RelatorioService;
import br.com.senai.almoxarifado.entity.Auditoria;
import br.com.senai.almoxarifado.service.AuditoriaService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/relatorios")
public class RelatorioController {
    private final RelatorioService service;
    private final AuditoriaService auditoriaService;

    public RelatorioController(RelatorioService service, AuditoriaService auditoriaService) {
        this.service = service;
        this.auditoriaService = auditoriaService;
    }

    @GetMapping("/valor-total-categoria")
    public List<Map<String, Object>> valorTotalPorCategoria() {
        return service.valorTotalPorCategoria();
    }

    @GetMapping("/movimentacoes")
    public List<Map<String, Object>> movimentacoesPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicial,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFinal) {
        return service.movimentacoesPorPeriodo(dataInicial, dataFinal);
    }

    @GetMapping("/maior-volume-saida")
    public List<Map<String, Object>> produtosMaiorVolumeSaida(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicial,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFinal) {
        return service.produtosMaiorVolumeSaida(dataInicial, dataFinal);
    }

    @GetMapping("/limites-estoque")
    public List<Map<String, Object>> produtosLimiteEstoque() {
        return service.produtosLimiteEstoque();
    }

    @GetMapping("/auditoria")
    public List<Auditoria> auditoria() {
        return auditoriaService.listar();
    }
}
