package br.com.senai.almoxarifado.controller;

import br.com.senai.almoxarifado.dto.MovimentacaoDTO;
import br.com.senai.almoxarifado.entity.EntradaEstoque;
import br.com.senai.almoxarifado.entity.SaidaEstoque;
import br.com.senai.almoxarifado.repository.SaidaEstoqueRepository;
import br.com.senai.almoxarifado.service.EstoqueService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/estoque")
public class EstoqueController {
    private final EstoqueService service;
    private final SaidaEstoqueRepository saidaRepository;

    public EstoqueController(EstoqueService service, SaidaEstoqueRepository saidaRepository) {
        this.service = service;
        this.saidaRepository = saidaRepository;
    }

    @PostMapping("/entrada")
    public EntradaEstoque entrada(@RequestBody MovimentacaoDTO dto,
                                  @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.registrarEntrada(dto, usuario);
    }

    @PostMapping("/saida")
    public SaidaEstoque saida(@RequestBody MovimentacaoDTO dto,
                              @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.registrarSaida(dto, usuario);
    }

    @GetMapping("/saidas")
    public List<SaidaEstoque> listarSaidasDecrescente() {
        return saidaRepository.findAllByOrderByDataSaidaDesc();
    }
}
