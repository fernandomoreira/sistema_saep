package br.com.senai.almoxarifado.repository;

import br.com.senai.almoxarifado.entity.EntradaEstoque;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntradaEstoqueRepository extends JpaRepository<EntradaEstoque, Integer> {
    boolean existsByProdutoId(Integer idProduto);
}
