package br.com.senai.almoxarifado.repository;

import br.com.senai.almoxarifado.entity.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
