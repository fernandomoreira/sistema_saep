package br.com.senai.almoxarifado.repository;

import br.com.senai.almoxarifado.entity.Auditoria;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditoriaRepository extends JpaRepository<Auditoria, Integer> {
    List<Auditoria> findAllByOrderByDataHoraDesc();
}
