package br.com.senai.almoxarifado.controller;

import br.com.senai.almoxarifado.entity.Categoria;
import br.com.senai.almoxarifado.service.CategoriaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {
    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    @PostMapping
    public Categoria cadastrar(@RequestBody Categoria categoria,
                               @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.cadastrar(categoria, usuario);
    }

    @GetMapping
    public List<Categoria> listar() {
        return service.listar();
    }

    @PutMapping("/{id}")
    public Categoria atualizar(@PathVariable Integer id,
                               @RequestBody Categoria categoria,
                               @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        return service.atualizar(id, categoria, usuario);
    }

    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Integer id,
                        @RequestHeader(value = "X-Usuario", required = false) String usuario) {
        service.excluir(id, usuario);
    }
}
