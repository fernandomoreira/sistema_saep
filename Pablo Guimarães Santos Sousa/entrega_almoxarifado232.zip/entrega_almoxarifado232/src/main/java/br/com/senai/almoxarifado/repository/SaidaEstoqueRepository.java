package br.com.senai.almoxarifado.repository;

import br.com.senai.almoxarifado.entity.SaidaEstoque;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SaidaEstoqueRepository extends JpaRepository<SaidaEstoque, Integer> {
    List<SaidaEstoque> findAllByOrderByDataSaidaDesc();
    boolean existsByProdutoId(Integer idProduto);
}
