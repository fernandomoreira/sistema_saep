package br.com.senai.almoxarifado.service;

import br.com.senai.almoxarifado.entity.Categoria;
import br.com.senai.almoxarifado.exception.RegraNegocioException;
import br.com.senai.almoxarifado.repository.CategoriaRepository;
import br.com.senai.almoxarifado.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CategoriaService {
    private final CategoriaRepository categoriaRepository;
    private final ProdutoRepository produtoRepository;
    private final AuditoriaService auditoriaService;

    public CategoriaService(CategoriaRepository categoriaRepository,
                            ProdutoRepository produtoRepository,
                            AuditoriaService auditoriaService) {
        this.categoriaRepository = categoriaRepository;
        this.produtoRepository = produtoRepository;
        this.auditoriaService = auditoriaService;
    }

    public List<Categoria> listar() {
        return categoriaRepository.findAll();
    }

    @Transactional
    public Categoria cadastrar(Categoria categoria, String usuario) {
        validar(categoria);
        categoria.setNome(categoria.getNome().trim());
        Categoria salva = categoriaRepository.save(categoria);
        auditoriaService.registrar(usuario, "CADASTROU", "Categoria", salva.getId(), "Cadastrou categoria: " + salva.getNome());
        return salva;
    }

    @Transactional
    public Categoria atualizar(Integer id, Categoria dados, String usuario) {
        validar(dados);
        Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Categoria nao encontrada."));

        String nomeAntigo = categoria.getNome();
        categoria.setNome(dados.getNome().trim());
        categoria.setDescricao(dados.getDescricao());

        Categoria salva = categoriaRepository.save(categoria);
        auditoriaService.registrar(usuario, "EDITOU", "Categoria", salva.getId(),
                "Editou categoria de '" + nomeAntigo + "' para '" + salva.getNome() + "'.");
        return salva;
    }

    @Transactional
    public void excluir(Integer id, String usuario) {
        Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Categoria nao encontrada."));

        if (produtoRepository.existsByCategoriaId(id)) {
            throw new RegraNegocioException("Nao e possivel excluir categoria com produtos cadastrados.");
        }

        categoriaRepository.delete(categoria);
        auditoriaService.registrar(usuario, "EXCLUIU", "Categoria", id, "Excluiu categoria: " + categoria.getNome());
    }

    private void validar(Categoria categoria) {
        if (categoria.getNome() == null || categoria.getNome().isBlank()) {
            throw new RegraNegocioException("O nome da categoria e obrigatorio.");
        }
    }
}
