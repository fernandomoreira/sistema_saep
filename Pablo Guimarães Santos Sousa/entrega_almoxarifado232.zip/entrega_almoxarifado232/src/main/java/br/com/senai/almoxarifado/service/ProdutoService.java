package br.com.senai.almoxarifado.service;

import br.com.senai.almoxarifado.dto.ProdutoDTO;
import br.com.senai.almoxarifado.entity.Categoria;
import br.com.senai.almoxarifado.entity.Produto;
import br.com.senai.almoxarifado.exception.RegraNegocioException;
import br.com.senai.almoxarifado.repository.CategoriaRepository;
import br.com.senai.almoxarifado.repository.EntradaEstoqueRepository;
import br.com.senai.almoxarifado.repository.ProdutoRepository;
import br.com.senai.almoxarifado.repository.SaidaEstoqueRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProdutoService {
    private static final int LIMITE_MAXIMO_ESTOQUE = 100;

    private final ProdutoRepository produtoRepository;
    private final CategoriaRepository categoriaRepository;
    private final EntradaEstoqueRepository entradaRepository;
    private final SaidaEstoqueRepository saidaRepository;
    private final AuditoriaService auditoriaService;

    public ProdutoService(ProdutoRepository produtoRepository,
                          CategoriaRepository categoriaRepository,
                          EntradaEstoqueRepository entradaRepository,
                          SaidaEstoqueRepository saidaRepository,
                          AuditoriaService auditoriaService) {
        this.produtoRepository = produtoRepository;
        this.categoriaRepository = categoriaRepository;
        this.entradaRepository = entradaRepository;
        this.saidaRepository = saidaRepository;
        this.auditoriaService = auditoriaService;
    }

    @Transactional
    public Produto cadastrar(ProdutoDTO dto, String usuario) {
        validar(dto);
        Categoria categoria = buscarCategoria(dto.idCategoria);

        Produto produto = new Produto();
        produto.setNome(dto.nome.trim());
        produto.setCategoria(categoria);
        produto.setUnidadeMedida(dto.unidadeMedida.trim());
        produto.setQuantidadeAtual(dto.quantidadeAtual);
        produto.setValorUnitario(dto.valorUnitario);

        Produto salvo = produtoRepository.save(produto);
        auditoriaService.registrar(usuario, "CADASTROU", "Produto", salvo.getId(), "Cadastrou produto: " + salvo.getNome());
        return salvo;
    }

    @Transactional
    public Produto atualizar(Integer id, ProdutoDTO dto, String usuario) {
        validar(dto);
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Produto nao encontrado."));
        Categoria categoria = buscarCategoria(dto.idCategoria);

        String nomeAntigo = produto.getNome();
        produto.setNome(dto.nome.trim());
        produto.setCategoria(categoria);
        produto.setUnidadeMedida(dto.unidadeMedida.trim());
        produto.setQuantidadeAtual(dto.quantidadeAtual);
        produto.setValorUnitario(dto.valorUnitario);

        Produto salvo = produtoRepository.save(produto);
        auditoriaService.registrar(usuario, "EDITOU", "Produto", salvo.getId(),
                "Editou produto de '" + nomeAntigo + "' para '" + salvo.getNome() + "'.");
        return salvo;
    }

    @Transactional
    public void excluir(Integer id, String usuario) {
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Produto nao encontrado."));

        if (entradaRepository.existsByProdutoId(id) || saidaRepository.existsByProdutoId(id)) {
            throw new RegraNegocioException("Nao e possivel excluir produto com movimentacoes cadastradas.");
        }

        produtoRepository.delete(produto);
        auditoriaService.registrar(usuario, "EXCLUIU", "Produto", id, "Excluiu produto: " + produto.getNome());
    }

    public List<Produto> listar() {
        return produtoRepository.findAll();
    }

    private Categoria buscarCategoria(Integer idCategoria) {
        return categoriaRepository.findById(idCategoria)
                .orElseThrow(() -> new RegraNegocioException("Categoria nao encontrada."));
    }

    private void validar(ProdutoDTO dto) {
        if (dto.nome == null || dto.nome.isBlank()) {
            throw new RegraNegocioException("O nome do produto e obrigatorio.");
        }
        if (dto.idCategoria == null) {
            throw new RegraNegocioException("A categoria e obrigatoria.");
        }
        if (dto.unidadeMedida == null || dto.unidadeMedida.isBlank()) {
            throw new RegraNegocioException("A unidade de medida e obrigatoria.");
        }
        if (dto.valorUnitario == null || dto.valorUnitario.compareTo(BigDecimal.ZERO) < 0) {
            throw new RegraNegocioException("O valor unitario deve ser maior ou igual a zero.");
        }
        if (dto.quantidadeAtual == null || dto.quantidadeAtual < 0) {
            throw new RegraNegocioException("A quantidade nao pode ser negativa.");
        }
        if (dto.quantidadeAtual > LIMITE_MAXIMO_ESTOQUE) {
            throw new RegraNegocioException("A quantidade nao pode ultrapassar 100 unidades.");
        }
    }
}
