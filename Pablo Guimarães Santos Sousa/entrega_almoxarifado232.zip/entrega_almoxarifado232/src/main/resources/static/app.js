let categoriasCache = [];
let produtosCache = [];

document.addEventListener('DOMContentLoaded', function() {
    configurarUsuario();
    carregarTudo();

    document.getElementById('formCategoria').addEventListener('submit', adicionarCategoria);
    document.getElementById('formProduto').addEventListener('submit', adicionarProduto);
    document.getElementById('formEntrada').addEventListener('submit', registrarEntrada);
    document.getElementById('formSaida').addEventListener('submit', registrarSaida);
    document.getElementById('formMovimentacoes').addEventListener('submit', carregarMovimentacoesPeriodo);

    const hoje = new Date();
    const trintaDiasAtras = new Date(hoje.getTime() - (30 * 24 * 60 * 60 * 1000));
    document.getElementById('dataInicio').valueAsDate = trintaDiasAtras;
    document.getElementById('dataFim').valueAsDate = hoje;
});

function configurarUsuario() {
    const input = document.getElementById('usuarioAtual');
    input.value = localStorage.getItem('usuarioAtual') || '';
    input.addEventListener('input', () => localStorage.setItem('usuarioAtual', input.value.trim()));
}

function usuarioAtual() {
    return document.getElementById('usuarioAtual').value.trim() || 'Usuario nao informado';
}

function carregarTudo() {
    carregarCategorias();
    carregarProdutos();
    carregarSaidasEstoque();
    carregarSelectsCategorias();
    carregarSelectsProdutos();
}

async function apiFetch(url, options = {}) {
    options.headers = {
        ...(options.headers || {}),
        'X-Usuario': usuarioAtual()
    };

    const response = await fetch(`${API_URL}${url}`, options);
    if (response.ok) {
        return response.status === 204 ? null : response.json();
    }

    let mensagem = 'Erro ao processar a requisicao.';
    try {
        const erro = await response.json();
        mensagem = erro.erro || mensagem;
    } catch (e) {
        mensagem = response.statusText || mensagem;
    }
    throw new Error(mensagem);
}

function jsonOptions(body, method = 'POST') {
    return {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };
}

function mostrarMensagem(id, tipo, texto) {
    const elemento = document.getElementById(id);
    elemento.innerHTML = `<div class="alert alert-${tipo}">${texto}</div>`;
    setTimeout(() => {
        elemento.innerHTML = '';
    }, 3500);
}

function formatarMoeda(valor) {
    return `R$ ${(parseFloat(valor) || 0).toFixed(2)}`;
}

function dataHora(data) {
    return data ? new Date(data).toLocaleString('pt-BR') : '-';
}

async function carregarCategorias() {
    const lista = document.getElementById('categoriasList');
    try {
        categoriasCache = await apiFetch('/categorias');
        lista.innerHTML = '';

        if (!categoriasCache || categoriasCache.length === 0) {
            lista.innerHTML = '<div class="alert alert-info">Nenhuma categoria cadastrada</div>';
            return;
        }

        categoriasCache.forEach(categoria => {
            const div = document.createElement('div');
            div.className = 'list-group-item';
            div.innerHTML = `
                <div class="d-flex justify-content-between align-items-start gap-3">
                    <div>
                        <h5 class="mb-1">${categoria.nome}</h5>
                        <small class="text-muted">${categoria.descricao || 'Sem descricao'}</small><br>
                        <small class="text-muted">ID: ${categoria.id}</small>
                    </div>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="editarCategoria(${categoria.id})">Editar</button>
                        <button class="btn btn-outline-danger" onclick="excluirCategoria(${categoria.id})">Excluir</button>
                    </div>
                </div>
            `;
            lista.appendChild(div);
        });
    } catch (error) {
        console.error(error);
        lista.innerHTML = '<div class="alert alert-danger">Erro ao carregar categorias</div>';
    }
}

async function carregarSelectsCategorias() {
    try {
        const categorias = categoriasCache.length ? categoriasCache : await apiFetch('/categorias');
        const select = document.getElementById('produtoCategoria');
        select.innerHTML = '<option value="">Selecione uma categoria</option>';

        categorias.forEach(categoria => {
            const option = document.createElement('option');
            option.value = categoria.id;
            option.textContent = categoria.nome;
            select.appendChild(option);
        });
    } catch (error) {
        console.error(error);
    }
}

async function adicionarCategoria(e) {
    e.preventDefault();
    try {
        await apiFetch('/categorias', jsonOptions({
            nome: document.getElementById('categoriaNome').value,
            descricao: document.getElementById('categoriaDescricao').value
        }));

        mostrarMensagem('mensagemCategoria', 'success', 'Categoria adicionada com sucesso!');
        document.getElementById('formCategoria').reset();
        carregarCategorias();
        carregarSelectsCategorias();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemCategoria', 'danger', error.message);
    }
}

async function editarCategoria(id) {
    const categoria = categoriasCache.find(item => item.id === id);
    if (!categoria) return;

    const nome = prompt('Novo nome da categoria:', categoria.nome);
    if (nome === null) return;

    const descricao = prompt('Nova descricao:', categoria.descricao || '');
    if (descricao === null) return;

    try {
        await apiFetch(`/categorias/${id}`, jsonOptions({ nome, descricao }, 'PUT'));
        mostrarMensagem('mensagemCategoria', 'success', 'Categoria editada com sucesso!');
        carregarCategorias();
        carregarSelectsCategorias();
        carregarProdutos();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemCategoria', 'danger', error.message);
    }
}

async function excluirCategoria(id) {
    const categoria = categoriasCache.find(item => item.id === id);
    if (!confirm(`Excluir a categoria "${categoria?.nome || id}"?`)) return;

    try {
        await apiFetch(`/categorias/${id}`, { method: 'DELETE' });
        mostrarMensagem('mensagemCategoria', 'success', 'Categoria excluida com sucesso!');
        carregarCategorias();
        carregarSelectsCategorias();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemCategoria', 'danger', error.message);
    }
}

async function carregarProdutos() {
    const lista = document.getElementById('produtosList');
    try {
        produtosCache = await apiFetch('/produtos');
        lista.innerHTML = '';

        if (!produtosCache || produtosCache.length === 0) {
            lista.innerHTML = '<div class="alert alert-info">Nenhum produto cadastrado</div>';
            return;
        }

        produtosCache.forEach(produto => {
            const div = document.createElement('div');
            div.className = 'list-group-item';
            div.innerHTML = `
                <div class="d-flex justify-content-between align-items-start gap-3">
                    <div>
                        <h5 class="mb-1">${produto.nome}</h5>
                        <small class="text-muted">Categoria: ${produto.categoria?.nome || '-'}</small><br>
                        <small class="text-muted">Unidade: ${produto.unidadeMedida}</small><br>
                        <small class="text-muted">Valor: ${formatarMoeda(produto.valorUnitario)}</small>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-primary mb-2">Qtd: ${produto.quantidadeAtual}</span>
                        <div class="btn-group btn-group-sm d-block">
                            <button class="btn btn-outline-primary" onclick="editarProduto(${produto.id})">Editar</button>
                            <button class="btn btn-outline-danger" onclick="excluirProduto(${produto.id})">Excluir</button>
                        </div>
                    </div>
                </div>
            `;
            lista.appendChild(div);
        });
    } catch (error) {
        console.error(error);
        lista.innerHTML = '<div class="alert alert-danger">Erro ao carregar produtos</div>';
    }
}

async function carregarSelectsProdutos() {
    try {
        const produtos = produtosCache.length ? produtosCache : await apiFetch('/produtos');
        const selectEntrada = document.getElementById('entradaProduto');
        const selectSaida = document.getElementById('saidaProduto');
        selectEntrada.innerHTML = '<option value="">Selecione um produto</option>';
        selectSaida.innerHTML = '<option value="">Selecione um produto</option>';

        produtos.forEach(produto => {
            const texto = `${produto.nome} (${produto.categoria?.nome || 'sem categoria'})`;
            const optionEntrada = document.createElement('option');
            optionEntrada.value = produto.id;
            optionEntrada.textContent = texto;
            selectEntrada.appendChild(optionEntrada);

            const optionSaida = document.createElement('option');
            optionSaida.value = produto.id;
            optionSaida.textContent = texto;
            selectSaida.appendChild(optionSaida);
        });
    } catch (error) {
        console.error(error);
    }
}

async function adicionarProduto(e) {
    e.preventDefault();
    const produto = lerProdutoDoFormulario();

    try {
        await apiFetch('/produtos', jsonOptions(produto));
        mostrarMensagem('mensagemProduto', 'success', 'Produto adicionado com sucesso!');
        document.getElementById('formProduto').reset();
        carregarProdutos();
        carregarSelectsProdutos();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemProduto', 'danger', error.message);
    }
}

function lerProdutoDoFormulario() {
    return {
        nome: document.getElementById('produtoNome').value,
        idCategoria: parseInt(document.getElementById('produtoCategoria').value),
        unidadeMedida: document.getElementById('produtoUnidadeMedida').value,
        valorUnitario: parseFloat(document.getElementById('produtoPreco').value),
        quantidadeAtual: parseInt(document.getElementById('produtoQuantidade').value)
    };
}

async function editarProduto(id) {
    const produto = produtosCache.find(item => item.id === id);
    if (!produto) return;

    const nome = prompt('Novo nome do produto:', produto.nome);
    if (nome === null) return;
    const unidadeMedida = prompt('Nova unidade de medida:', produto.unidadeMedida);
    if (unidadeMedida === null) return;
    const valorUnitario = prompt('Novo valor unitario:', produto.valorUnitario);
    if (valorUnitario === null) return;
    const quantidadeAtual = prompt('Nova quantidade atual:', produto.quantidadeAtual);
    if (quantidadeAtual === null) return;
    const idCategoria = prompt('ID da categoria:', produto.categoria?.id || '');
    if (idCategoria === null) return;

    try {
        await apiFetch(`/produtos/${id}`, jsonOptions({
            nome,
            unidadeMedida,
            valorUnitario: parseFloat(valorUnitario),
            quantidadeAtual: parseInt(quantidadeAtual),
            idCategoria: parseInt(idCategoria)
        }, 'PUT'));
        mostrarMensagem('mensagemProduto', 'success', 'Produto editado com sucesso!');
        carregarProdutos();
        carregarSelectsProdutos();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemProduto', 'danger', error.message);
    }
}

async function excluirProduto(id) {
    const produto = produtosCache.find(item => item.id === id);
    if (!confirm(`Excluir o produto "${produto?.nome || id}"?`)) return;

    try {
        await apiFetch(`/produtos/${id}`, { method: 'DELETE' });
        mostrarMensagem('mensagemProduto', 'success', 'Produto excluido com sucesso!');
        carregarProdutos();
        carregarSelectsProdutos();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemProduto', 'danger', error.message);
    }
}

async function registrarEntrada(e) {
    e.preventDefault();
    try {
        await apiFetch('/estoque/entrada', jsonOptions({
            idProduto: parseInt(document.getElementById('entradaProduto').value),
            quantidade: parseInt(document.getElementById('entradaQuantidade').value)
        }));

        mostrarMensagem('mensagemEntrada', 'success', 'Entrada registrada com sucesso!');
        document.getElementById('formEntrada').reset();
        carregarProdutos();
        carregarSelectsProdutos();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemEntrada', 'danger', error.message);
    }
}

async function registrarSaida(e) {
    e.preventDefault();
    try {
        await apiFetch('/estoque/saida', jsonOptions({
            idProduto: parseInt(document.getElementById('saidaProduto').value),
            quantidade: parseInt(document.getElementById('saidaQuantidade').value)
        }));

        mostrarMensagem('mensagemSaida', 'success', 'Saida registrada com sucesso!');
        document.getElementById('formSaida').reset();
        carregarProdutos();
        carregarSelectsProdutos();
        carregarSaidasEstoque();
        carregarAuditoria();
    } catch (error) {
        mostrarMensagem('mensagemSaida', 'danger', error.message);
    }
}

async function carregarSaidasEstoque() {
    const tbody = document.getElementById('saidasBody');
    try {
        const saidas = await apiFetch('/estoque/saidas');
        tbody.innerHTML = '';

        if (!saidas || saidas.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center">Nenhuma saida registrada</td></tr>';
            return;
        }

        saidas.forEach(saida => {
            const row = tbody.insertRow();
            row.innerHTML = `
                <td>${saida.produto?.nome || '-'}</td>
                <td>${saida.quantidade}</td>
                <td>${new Date(saida.dataSaida).toLocaleDateString('pt-BR')}</td>
            `;
        });
    } catch (error) {
        console.error(error);
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Erro ao carregar saidas</td></tr>';
    }
}

async function carregarValorPorCategoria() {
    const tbody = document.getElementById('valorCategoriaBody');
    try {
        const dados = await apiFetch('/relatorios/valor-total-categoria');
        tbody.innerHTML = '';

        if (!dados || dados.length === 0) {
            tbody.innerHTML = '<tr><td colspan="2" class="text-center">Sem dados</td></tr>';
            return;
        }

        let totalGeral = 0;
        dados.forEach(item => {
            const valor = parseFloat(item.valor_total) || 0;
            totalGeral += valor;
            const row = tbody.insertRow();
            row.innerHTML = `<td>${item.categoria}</td><td>${formatarMoeda(valor)}</td>`;
        });

        const rowTotal = tbody.insertRow();
        rowTotal.innerHTML = `<td><strong>TOTAL</strong></td><td><strong>${formatarMoeda(totalGeral)}</strong></td>`;
    } catch (error) {
        alert(error.message);
    }
}

async function carregarMaiorVolumeSaida() {
    const inicio = document.getElementById('dataInicio').value;
    const fim = document.getElementById('dataFim').value;
    const tbody = document.getElementById('maiorVolumeSaidaBody');

    try {
        const dados = await apiFetch(`/relatorios/maior-volume-saida?dataInicial=${inicio}&dataFinal=${fim}`);
        tbody.innerHTML = '';

        if (!dados || dados.length === 0) {
            tbody.innerHTML = '<tr><td colspan="2" class="text-center">Sem dados</td></tr>';
            return;
        }

        dados.forEach(item => {
            const row = tbody.insertRow();
            row.innerHTML = `<td>${item.nome_produto}</td><td>${item.quantidade_total_saida}</td>`;
        });
    } catch (error) {
        alert(error.message);
    }
}

async function carregarLimitesEstoque() {
    const div = document.getElementById('limitesEstoqueDiv');
    try {
        const dados = await apiFetch('/relatorios/limites-estoque');

        if (!dados || dados.length === 0) {
            div.innerHTML = '<div class="alert alert-info">Nenhum produto em limite de estoque</div>';
            return;
        }

        let html = '<div class="alert alert-warning"><strong>Produtos em limite de estoque:</strong><ul>';
        dados.forEach(item => {
            html += `<li>${item.nome_produto} - Quantidade: ${item.quantidade_atual} - ${item.limite_atingido} (${item.percentual_nivel_atingido}%)</li>`;
        });
        html += '</ul></div>';
        div.innerHTML = html;
    } catch (error) {
        div.innerHTML = '<div class="alert alert-danger">Erro ao carregar relatorio</div>';
    }
}

async function carregarMovimentacoesPeriodo(e) {
    e.preventDefault();
    const dataInicio = document.getElementById('dataInicio').value;
    const dataFim = document.getElementById('dataFim').value;
    const tbody = document.getElementById('movimentacoesBody');

    try {
        const dados = await apiFetch(`/relatorios/movimentacoes?dataInicial=${dataInicio}&dataFinal=${dataFim}`);
        tbody.innerHTML = '';

        if (!dados || dados.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">Nenhuma movimentacao no periodo</td></tr>';
            return;
        }

        dados.forEach(item => {
            const row = tbody.insertRow();
            row.innerHTML = `
                <td>${item.nome_produto}</td>
                <td>${item.total_entradas}</td>
                <td>${item.total_saidas}</td>
                <td>${item.saldo_periodo}</td>
                <td>${formatarMoeda(item.valor_total_financeiro_entradas)}</td>
                <td>${formatarMoeda(item.valor_total_financeiro_saidas)}</td>
            `;
        });
    } catch (error) {
        alert(error.message);
    }
}

async function carregarAuditoria() {
    const tbody = document.getElementById('auditoriaBody');
    try {
        const dados = await apiFetch('/relatorios/auditoria');
        tbody.innerHTML = '';

        if (!dados || dados.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">Nenhuma alteracao registrada</td></tr>';
            return;
        }

        dados.forEach(item => {
            const row = tbody.insertRow();
            row.innerHTML = `
                <td>${dataHora(item.dataHora)}</td>
                <td>${item.usuario}</td>
                <td>${item.acao}</td>
                <td>${item.entidade}</td>
                <td>${item.idRegistro || '-'}</td>
                <td>${item.descricao}</td>
            `;
        });
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">${error.message}</td></tr>`;
    }
}
