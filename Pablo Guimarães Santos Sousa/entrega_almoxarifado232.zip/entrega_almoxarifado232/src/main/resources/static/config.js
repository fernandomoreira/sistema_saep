// API Spring Boot local, igual ao padrao usado no projeto anterior.
const API_URL = 'http://localhost:8080';
