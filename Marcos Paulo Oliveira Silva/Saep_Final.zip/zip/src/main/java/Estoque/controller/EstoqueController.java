package Estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.transaction.annotation.Transactional; 

import Estoque.model.Produto;
import Estoque.model.Categoria;
import Estoque.repository.CategoriaRepository;
import Estoque.repository.ProdutoRepository;
import Estoque.repository.MovimentacaoRepository; 
import Estoque.service.EstoqueService;

@Controller
public class EstoqueController {

    private final ProdutoRepository produtoRepository;
    private final CategoriaRepository categoriaRepository;
    private final EstoqueService estoqueService;
    private final MovimentacaoRepository movimentacaoRepository;

    EstoqueController(ProdutoRepository produtoRepository, CategoriaRepository categoriaRepository, 
                      EstoqueService estoqueService, MovimentacaoRepository movimentacaoRepository) {
        this.produtoRepository = produtoRepository;
        this.categoriaRepository = categoriaRepository;
        this.estoqueService = estoqueService;
        this.movimentacaoRepository = movimentacaoRepository; // INICIALIZADO AQUI
    }

    @GetMapping("/")
    public String paginaInicial(Model model) {
        model.addAttribute("produtos", produtoRepository.findAll());
        model.addAttribute("categorias", categoriaRepository.findAll()); 
        
        if (!model.containsAttribute("novoProduto")) {
            model.addAttribute("novoProduto", new Produto());
        }
        if (!model.containsAttribute("novaCategoria")) {
            model.addAttribute("novaCategoria", new Categoria()); 
        }
        
        return "index";
    }

    @PostMapping("/produtos/salvar")
    public String salvarProduto(@ModelAttribute("novoProduto") Produto produto) {
        try {
            estoqueService.cadastrarProduto(produto);
        } catch (IllegalArgumentException e) {
            System.out.println("LOG TERMINAL [ERRO]: " + e.getMessage());
        }
        return "redirect:/";
    }

    @PostMapping("/categorias/salvar")
    public String salvarCategoria(@ModelAttribute("novaCategoria") Categoria categoria) {
        try {
            categoriaRepository.save(categoria);
            System.out.println("LOG TERMINAL: Nova categoria '" + categoria.getNome() + "' cadastrada!");
        } catch (Exception e) {
            System.out.println("LOG TERMINAL [ERRO]: " + e.getMessage());
        }
        return "redirect:/";
    }

    @GetMapping("/produtos/editar/{id}")
    public String editarProduto(@PathVariable("id") Integer id, Model model) {
        Produto produto = produtoRepository.findById(id).orElse(new Produto());
        model.addAttribute("produtos", produtoRepository.findAll());
        model.addAttribute("categorias", categoriaRepository.findAll());
        model.addAttribute("novoProduto", produto);
        model.addAttribute("novaCategoria", new Categoria());
        return "index";
    }

    
    @Transactional
    @GetMapping("/produtos/deletar/{id}")
    public String deletarProduto(@PathVariable("id") Integer id) {
        try {
           
            movimentacaoRepository.deleteAll();
            
         
            produtoRepository.deleteById(id);
            
            System.out.println("LOG TERMINAL: Produto ID " + id + " e seu histórico foram removidos.");
        } catch (Exception e) {
            System.out.println("LOG TERMINAL [ERRO]: Falha ao deletar -> " + e.getMessage());
        }
        return "redirect:/";
    }
}