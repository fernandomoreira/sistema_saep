package Estoque.model;

public enum TipoMovimentacao {
    ENTRADA,
    SAIDA
}
