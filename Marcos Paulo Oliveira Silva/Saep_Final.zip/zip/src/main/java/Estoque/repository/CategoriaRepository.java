package Estoque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Estoque.model.Categoria;


public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}

