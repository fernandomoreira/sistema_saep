package Estoque.repository;

import java.util.List; // Importação que estava faltando
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import Estoque.model.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
    
    @Query(value = "SELECT p.nome, p.quantidade_atual, p.limite_minimo, p.limite_maximo, " +
                   "ROUND(((p.quantidade_atual / p.limite_maximo) * 100), 2) AS percentual " +
                   "FROM Produto p WHERE p.quantidade_atual <= p.limite_minimo OR p.quantidade_atual >= p.limite_maximo", 
           nativeQuery = true)
    List<Object[]> findAlertasLimites();
}