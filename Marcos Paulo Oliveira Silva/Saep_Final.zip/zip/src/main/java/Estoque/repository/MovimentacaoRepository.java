package Estoque.repository;
import Estoque.model.Movimentacao;
import Estoque.model.TipoMovimentacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;

public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Long> {
    List<Movimentacao> findByTipoOrderByDataMovimentoDesc(TipoMovimentacao tipo);

    @Query(value = "SELECT p.nome, p.unidade_medida, " +
                   "COALESCE(SUM(CASE WHEN m.tipo = 'ENTRADA' THEN m.quantidade ELSE 0 END), 0) AS total_entradas, " +
                   "COALESCE(SUM(CASE WHEN m.tipo = 'SAIDA' THEN m.quantidade ELSE 0 END), 0) AS total_saidas, " +
                   "(COALESCE(SUM(CASE WHEN m.tipo = 'ENTRADA' THEN m.quantidade ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN m.tipo = 'SAIDA' THEN m.quantidade ELSE 0 END), 0)) AS saldo, " +
                   "COALESCE(SUM(CASE WHEN m.tipo = 'ENTRADA' THEN m.quantidade * m.valor_unitario ELSE 0 END), 0) AS fin_entrada, " +
                   "COALESCE(SUM(CASE WHEN m.tipo = 'SAIDA' THEN m.quantidade * m.valor_unitario ELSE 0 END), 0) AS fin_saida " +
                   "FROM Produto p LEFT JOIN Movimentacao m ON p.id = m.produto_id AND m.data_movimento BETWEEN :inicio AND :fim " +
                   "GROUP BY p.id, p.nome, p.unidade_medida", nativeQuery = true)
    List<Object[]> findRelatorioPeriodo(@Param("inicio") LocalDateTime inicio, @Param("fim") LocalDateTime fim);
}