package Estoque.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Estoque.model.Movimentacao;
import Estoque.model.Produto;
import Estoque.model.TipoMovimentacao;
import Estoque.repository.MovimentacaoRepository;
import Estoque.repository.ProdutoRepository;

@Service
public class EstoqueService {

    private final ProdutoRepository produtoRepository;
    private final MovimentacaoRepository movimentacaoRepository;

    EstoqueService(MovimentacaoRepository movimentacaoRepository, ProdutoRepository produtoRepository) {
        this.movimentacaoRepository = movimentacaoRepository;
        this.produtoRepository = produtoRepository;
    }

    @Transactional
    public Produto cadastrarProduto(Produto produto) {
        
        if (produto.getValorUnitario() == null || produto.getValorUnitario().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("O valor unitário deve ser maior que zero.");
        }
        
        if (produto.getQuantidadeAtual() != null && produto.getQuantidadeAtual() < 0) {
            throw new IllegalArgumentException("A quantidade inicial não pode ser negativa.");
        }

        if (produto.getLimiteMinimo() == null) produto.setLimiteMinimo(0);
        if (produto.getLimiteMaximo() == null) produto.setLimiteMaximo(100);

        int qtdInicial = (produto.getQuantidadeAtual() != null) ? produto.getQuantidadeAtual() : 0;
        
        boolean ehNovo = (produto.getId() == null);

        Produto produtoSalvo = produtoRepository.save(produto);

       
        if (ehNovo && qtdInicial > 0) {
            Movimentacao mov = new Movimentacao();
            mov.setProduto(produtoSalvo); 
            mov.setQuantidade(qtdInicial);
            mov.setTipo(TipoMovimentacao.ENTRADA);
            mov.setDataMovimento(LocalDateTime.now()); 
            mov.setValorUnitario(produtoSalvo.getValorUnitario());

            movimentacaoRepository.save(mov); 
        }

        return produtoSalvo; 
      
    }

    @Transactional
    public Movimentacao registrarEntrada(Movimentacao mov) {
   
        Produto produto = produtoRepository.findById(mov.getProduto().getId())
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado com o ID fornecido."));
        
        if (mov.getQuantidade() == null || mov.getQuantidade() <= 0) {
            throw new IllegalArgumentException("A quantidade movimentada deve ser maior que zero.");
        }

        produto.setQuantidadeAtual(produto.getQuantidadeAtual() + mov.getQuantidade());
        produtoRepository.save(produto); 

        mov.setTipo(TipoMovimentacao.ENTRADA);
        mov.setDataMovimento(LocalDateTime.now());
        mov.setValorUnitario(produto.getValorUnitario()); 

        return movimentacaoRepository.save(mov); 
    }
}